AROoba CAM — Android starter project

WHAT'S INCLUDED
- Black luxury camera screen with gold accents
- Front-facing live camera preview
- Selectable tint-style preview effects (Natural, Gold, Rose, Cool, Noir, Violet)
- Capture button saves photos to Pictures/Arooba Cam

IMPORTANT LIMITATION
This is a starter Android Studio project, not an installed APK. The tint filters are simple screen overlays; the saved photo is the original camera capture, not a fully processed filter image. Snapchat-style face tracking, AR masks, stickers, and filtered-photo export need additional ML/graphics work.

HOW TO BUILD
1. Install Android Studio on a computer.
2. Unzip AroobaCam.zip.
3. In Android Studio choose Open, then select the AroobaCam folder.
4. Let Gradle sync and install the Android SDK if prompted.
5. Connect your Android phone with USB debugging enabled, or use an emulator with a camera.
6. Press Run. Accept the camera permission on your phone.

Package name: com.aroobacam
App label: Arooba Cam
Minimum Android: Android 6.0 (API 23)
