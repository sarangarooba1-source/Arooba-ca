package com.aroobacam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: View
    private lateinit var capture: ImageCapture
    private lateinit var status: TextView
    private var frontCamera = true

    private data class Filter(val name: String, val tint: Int)
    private val filters = listOf(
        Filter("NATURAL", Color.TRANSPARENT),
        Filter("GOLD", 0x22D8B56B),
        Filter("ROSE", 0x22D9829A),
        Filter("COOL", 0x223D78C5),
        Filter("NOIR", 0x44000000),
        Filter("VIOLET", 0x224E267D)
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else status.text = "Camera permission is needed"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        overlay = findViewById(R.id.filterOverlay)
        status = findViewById(R.id.statusText)
        capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
        buildFilters()
        findViewById<Button>(R.id.captureButton).setOnClickListener { takePhoto() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildFilters() {
        val row = findViewById<LinearLayout>(R.id.filterRow)
        filters.forEach { filter ->
            val button = Button(this).apply {
                text = filter.name
                setTextColor(Color.WHITE)
                textSize = 11f
                letterSpacing = 0.08f
                backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF242424.toInt())
                setOnClickListener {
                    overlay.setBackgroundColor(filter.tint)
                    status.text = "${filter.name} filter selected"
                }
            }
            row.addView(button, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = 8 })
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val selector = if (frontCamera) CameraSelector.DEFAULT_FRONT_CAMERA
                          else CameraSelector.DEFAULT_BACK_CAMERA
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, capture)
            } catch (e: Exception) {
                status.text = "Camera could not start"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val name = "AroobaCam_${System.currentTimeMillis()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Arooba Cam")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    status.text = "Saved to Pictures / Arooba Cam"
                }
                override fun onError(exception: ImageCaptureException) {
                    status.text = "Could not save photo. Try again."
                }
            })
    }
}
